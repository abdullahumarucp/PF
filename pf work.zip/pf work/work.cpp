#include<iostream>
#include<fstream>
using namespace std;

int main()
{
	ifstream fin, fin1, fin2;
	ofstream fout, fout1;

	int age = 0;
	char bL = '\0';
	char bS = '\0';
	char name[20] = { '\0' };

	char bin = '\0';

	fin.open("Data.txt");
	fout.open("new_Data.txt");


	if (!fin.is_open())
	{
		cout << "File not Found!";
	}
	else
	{
		while (!fin.eof())
		{
			fin >> age;
			fin >> bin;
			fin >> bL;
			fin >> bin;
			fin >> bS;
			fin.ignore();
			fin.getline(name, 20);

			fout << age << " " << bL << " " << bS << " " << name << endl;
		}
	}
	int option = 0;
	cout << "if you want to ADD any other data press 1 if not press 2 " << endl;
	cin >> option;

	while (option!=2)
	{
		if (option==1)
		{
			cout << "age of donar:" << endl;
			cin >> age;
			cout << " blood group of donar: " << endl;
			cin >> bL;
			cout << " blood sign of donar: " << endl;
			cin >> bS;
			cout << "enter name of donar:" << endl;
			cin.ignore();
			cin.getline(name, 20, '\n');
			fout << age << " " << bL << " " << bS << " " << name << endl;
			break;
		}
		else
		{
			cout << "option not avail!" << endl;
			break;
		}
	}
	
	cout << endl << endl;




	fin1.open("new_Data.txt");
	fout1.open("record.txt");

	char bL_in = '\0';
	char bS_in = '\0';

	cout << "Enter letter of BG: " << endl;
	cin >> bL_in;
	cout << "Enetr sign of BG: " << endl;
	cin >> bS_in;

	if (!fin1.is_open())
	{
		cout << "File not found!";
	}
	else
	{
		while (!fin1.eof())
		{
			fin1 >> age;
			fin1 >> bL;
			fin1 >> bS;
			fin1.ignore();
			fin1.getline(name, 20);

			if (bL == bL_in && bS == bS_in)
			{
				fout1 << age << " " << bL << " " << bS << " " << name << endl;
			}
			
			
		}
	}

	fin2.open("record.txt");
	int new_age = 0;
	char info[50] = { '\0' };


	if (!fin2.is_open())
	{
		cout << "File not found!";
	}
	else
	{
		fin2 >> new_age;
		fin2.ignore();
		fin2.getline(info, 50);
		while (!fin2.eof())
		{
			fin2 >> age;
			if (new_age < age)
			{
				cout << new_age << " " << info<<endl;
				
			}
			else
			{
				fin2.ignore();
				fin2.getline(info, 50);
				cout << age << " " << info<<endl;
				break;
			}
		}
	}



	fin.close();
	fout.close();
	fin1.close();
	fout1.close();
	system("pause");
	return 0;
}