#include<iostream>
#include<fstream>
using namespace std;

int sum(int&a,int&b,int&c,int&d);
void greater(int&s1, int&s2, int&s3, int&s4);
void product(int &p1, int &s1);
void display1();

int main()
{
	char arr[50] = { '\0' };
	char arr1[15] = { '\0' };
	char arr2[15] = { '\0' };
	char arr3[15] = { '\0' };
	char arr4[15] = { '\0' };
	int p1 = 0; int p2 = 0; int p3 = 0; int p4 = 0;
	int s1 = 0; int s2 = 0; int s3 = 0; int s4 = 0;
	int option = 0;
	char bin;
	
	ifstream fin;
	ofstream fout;

	fin.open("data.txt");
	if (!fin.is_open())
	{
		cout << "not found !" << endl;
	}
	else
	{
		cout << "                       menu " << endl;
		cout << "_________________________________________________" << endl;
		cout << "! enter option 1 to get most sold ticket        ! " << endl;
		cout << "! enter option 2 to get total tickets sold      ! " << endl;
		cout << "! enter option 3 to get most sold ticket income ! " << endl;
		cout << "!_______________________________________________!" << endl;

		cout << "enter option : ";
		cin >> option;
		cout << endl;


		fin.getline(arr, 50);
		fin.getline(arr1, 15, '@');
		fin >> p1;
		fin >> bin;
		fin >> s1;
		fin >> bin;
		fin.getline(arr2, 15, '@');
		fin >> p2;
		fin >> bin;
		fin >> s2;
		fin >> bin;
		fin.getline(arr3, 15, '@');
		fin >> p3;
		fin >> bin;
		fin >> s3;
		fin >> bin;
		fin.getline(arr4, 15, '@');
		fin >> p4;
		fin >> bin;
		fin >> s4;

		if (option == 1)
		{
			greater(s1, s2, s3, s4);
			char option2 = '\0';
			cout << "press y/Y for continue OR press n/N to end :";
			cin >> option2;
			cout << endl;
			if (option2 == 'y' &&'Y')
			{
				cout << "                       menu " << endl;
				cout << "_________________________________________________" << endl;
				cout << "! enter option 2 to get total tickets sold      ! " << endl;
				cout << "! enter option 3 to get most sold ticket income ! " << endl;
				cout << "!_______________________________________________!" << endl;
				int option3 = 0;
				cout << "enter option :";
				cin >> option3;
				cout << endl;
				if (option3 == 2)
				{
					int v = sum(s1, s2, s3, s4);
					cout << "the sum of sold tickets is : " << v << endl;
				}
				else if (option3 == 3)
				{
					product(p1, s1);
				}
				else
				{
					display1();
				}

			}
			else if (option2 == 'n' && 'N')
			{
				cout << "program ended" << endl;
			}
			else
			{
				display1();
			}
		}

		else if (option == 2)
		{
			int v = sum(s1, s2, s3, s4);
			cout << "the sum of sold tickets is : " << v << endl;
			cout << "press y/Y for continue OR press n/N to end :";
			char option4 = '\0';
			cin >> option4;
			cout << endl;
			if (option4 == 'y'&& 'Y')
			{
				cout << "                       menu " << endl;
				cout << "_________________________________________________" << endl;
				cout << "! enter option 1 to get most sold ticket        ! " << endl;
				cout << "! enter option 3 to get most sold ticket income ! " << endl;
				cout << "!_______________________________________________!" << endl;
				int option5 = 0;
				cout << "enter option : ";
				cin >> option5;
				cout << endl;
				if (option5 == 1)
				{
					greater(s1, s2, s3, s4);
				}
				else if (option5 == 3)
				{
					product(p1, s1);
				}
				else
				{
					display1();
				}
			}
			else if (option4 == 'n' && 'N')
			{
				cout << "program ended" << endl;
			}
			else
			{
				display1();
			}
		}
		else if (option == 3)
		{
			product(p1, s1);
			cout << "press y/Y for continue OR press n/N to end :";
			char option6 = { '\0' };
			cin >> option6;
			cout << endl;
			if (option6 == 'y' && 'Y')
			{
				cout << "                       menu " << endl;
				cout << "_________________________________________________" << endl;
				cout << "! enter option 1 to get most sold ticket        ! " << endl;
				cout << "! enter option 2 to get total tickets sold      ! " << endl;
				cout << "!_______________________________________________!" << endl;
				int option7 = 0;
				cout << "enter option : ";
				cin >> option7;
				if (option7 == 1)
				{
					greater(s1, s2, s3, s4);
				}
				else if (option7 == 2)
				{
					int v = sum(s1, s2, s3, s4);
					cout << "the sum of sold tickets is : " << v << endl;
				}
				else
				{
					display1();
				}
			}
			else if (option6 == 'n'&& 'N')
			{
				cout << "program ended" << endl;
			}
			else
			{
				display1();
			}
		}
	}
	system("pause");
	return 0;
}


int sum(int&a, int&b, int&c, int&d)
{
	int s = a + b + c + d;
	return s;
}

void greater(int&s1, int&s2, int&s3, int&s4)
{
	if (s1 > s2&&s1 > s3&&s1 > s4)
	{
		cout << "imax" << endl;
	}
	else if (s2 > s1&&s2 > s3&&s2 > s4)
	{
		cout << "cinepax" << endl;
	}
	else if (s3 > s2&&s3 > s1&&s3 > s4)
	{
		cout << "cue" << endl;
	}
	else
	{
		cout << "arena" << endl;
	}
}

void product(int &p1, int &s1)
{
	int v=p1*s1;
	cout << "total earn from highest sold : "<<v << endl;
}

void display1()
{
	cout << "option not avail right-now" << endl;
}