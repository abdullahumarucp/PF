#include<iostream>
#include<fstream>
using namespace std;

void display();
void display1();
int input();
int fabicon();

int main()
{
	fabicon();
	system("pause");
	return 0;
}

void display()
{
	cout << "enter number :";
}

void display1()
{
	cout << "fabicon series is : 0 , 1 , ";
}

int input()
{
	int a = 0;
	display();
	cin >> a;
	return a;
}

int fabicon()
{
	int o = 0; int m = 1; int next;
	int n = input();
	display1();
	for (int i = 0; i < n-2; i++)
	{
		next = o + m;
		o = m;
		m = next;
		cout << next << " , ";
	}
	return next;
}

