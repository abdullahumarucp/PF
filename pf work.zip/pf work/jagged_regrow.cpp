#include<iostream>
using namespace std;
void input(int** dptr, int row, int* col);
void print(int** dptr, int row, int* col);
void copy_data(int* old_ptr, int* new_ptr, int size);
int* regrow_1D(int* old_ptr, int size);
int* shrink(int* old_ptr, int size);

int main()
{
	int row = 0, row_input = 0, new_val=0;

	cout << "enter row size: ";
	cin >> row;

	int* length = new int[row];
	for (int i = 0; i < row; i++)
	{
		cout << "enter col size: " << endl;
		cin >> length[i];
	}

	int** dptr = new int* [row];
	for (int i = 0; i < row; i++)
	{
		dptr[i] = new int[length[i]];
	}
	input(dptr, row, length);
	print(dptr, row, length);

	cout << "enter row number to regrow: " << endl;
	cin >> row_input;
	cout << "enter new value: " << endl;
	cin >> new_val;

	dptr[row_input]=regrow_1D(dptr[row_input], length[row_input]);
	dptr[row_input][length[row_input]] = new_val;
	length[row_input]++;

	print(dptr, row, length);

	cout << "enter row number to shrink: " << endl;
	cin >> row_input;

	dptr[row_input] = shrink(dptr[row_input], length[row_input]);
	length[row_input]--;

	print(dptr, row, length);






	system("Pause");
	return 0;
}
void input(int** dptr, int row, int* col)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col[i]; j++)
		{
			cout << "enter value: " << endl;
			cin >> dptr[i][j];
		}
	}
}
void print(int** dptr, int row, int* col)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col[i]; j++)
		{
			//cout << "enter value: " << endl;
			cout<<dptr[i][j]<<" ";
		}
		cout <<endl;
	}
}
int* regrow_1D(int* old_ptr, int size)
{
	int* new_ptr = new int[size + 1];
	if (size == 0) 
	{
		return new_ptr;
	}
	else
	{
		copy_data(old_ptr, new_ptr, size);
		delete[] old_ptr;
		return new_ptr;
	}

}
void copy_data(int* old_ptr, int* new_ptr, int size)
{
	for (int i = 0; i < size; i++)
	{
		new_ptr[i] = old_ptr[i];
	}
}
int* shrink(int* old_ptr, int size)
{
	if (size == 1)
	{
		int* new_ptr = nullptr;
		delete[] old_ptr;
		return new_ptr;
	}
	else
	{
		int* new_ptr = new int[size - 1];
		copy_data(old_ptr, new_ptr, size - 1);
		delete[] old_ptr;
		return new_ptr;
	}
}