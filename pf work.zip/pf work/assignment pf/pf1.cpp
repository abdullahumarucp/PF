#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	int input = 0, serial_no = 0;
	int size1 = 0, size2 = 0, i = 0, line_no = 0;
	int pf = 0, calculus = 0, pakstudy = 0, dld = 0, english = 0, sum = 0;
	float percentage = 0.0;
	char reg_no[14], check_reg_no[14], password[11], check_password[11];
	bool start = false, found_reg = true, found_pass = true;
	cout << "\tSTUDENT PORATL\n\n";
	cout << "1.Register\n2.Login In\n";
	cout << "Enter your desire option: ";
	cin >> input;
	ofstream fout;
	ifstream fin;
	switch (input)
	{
	case 1:


		// For registration number
		fout.open("reg.txt", ios::app);
		if (fout.is_open())
		{


			fin.open("reg.txt");
			while (fin >> serial_no)
			{
				start = true;
				fin.ignore();
				fin >> reg_no;
			}
			fin.close();
			if (start == false)
			{
				fout << 1;
			}
			else
			{
				fout << endl << serial_no + 1;
			}
			cout << "Enter registration number: ";
			cin >> reg_no;
			fout << " " << reg_no;
			fout.close();

		}
		else
		{
			cout << "Reg file not opened!";
		}
		// For password
		fout.open("pswd.txt", ios::app);
		if (fout.is_open())
		{

			fin.open("pswd.txt");
			while (fin >> serial_no)
			{
				start = true;
				fin >> reg_no;
			}
			fin.close();
			if (start = false)
			{
				fout << 1;
			}
			else
			{
				fout << endl << serial_no + 1;
			}
			cout << "Enter password(Max 10 characters): ";
			cin >> password;
			fout << " " << password;
			fout.close();

		}
		else
		{
			cout << "Pswd file not opened!";
		}


	case 2:
		cout << "Enter registration number: ";
		cin >> reg_no;
		fin.open("reg.txt");
		if (fin.is_open())
		{
			while (fin >> serial_no)
			{
				found_reg = true;
				size1 = 0; size2 = 0;
				fin >> check_reg_no;
				line_no++;
				for (i = 0; reg_no[i] != '\0'; i++)
				{
					size1++;
				}
				for (i = 0; check_reg_no[i] != '\0'; i++)
				{
					size2++;


				}
				if (size1 == size2)
				{
					for (i = 0; reg_no[i] != '\0'; i++)
					{
						if (reg_no[i] != check_reg_no[i])
						{
							found_reg = false;
						}
					}
				}
				else
				{
					found_reg = false;
				}





				if (found_reg == true)
				{
					fin.close();
					fin.open("pswd.txt");
					if (fin.is_open())
					{
						cout << "Enter password: ";
						cin >> password;
						while (fin >> serial_no)
						{
							found_pass = true;
							size1 = 0; size2 = 0;
							fin >> check_password;
							if (serial_no == line_no)
							{
								for (i = 0; password[i] != '\0'; i++)
								{
									size1++;
								}
								for (i = 0; check_password[i] != '\0'; i++)
								{
									size2++;
								}
								if (size1 == size2)
								{
									for (i = 0; reg_no[i] != '\0'; i++)
									{
										if (password[i] != check_password[i])
										{
											found_pass = false;
										}
									}

								}
								else
								{
									found_pass = false;
								}

								if (found_pass == true)
								{
									fin.close();
									cout << "\nEnter marks out of 100\n";
									cout << "Enter marks in PF: ";
									cin >> pf;
									cout << "Enter marks in DLD: ";
									cin >> dld;
									cout << "Enter marks in pak study: ";
									cin >> pakstudy;
									cout << "Enter marks in English: ";
									cin >> english;
									cout << "Enter marks in Calculus: ";
									cin >> calculus;
									sum = pf + dld + pakstudy + calculus + english;
									percentage = (sum * 100) / 500.0;
									fout.open("result.txt", ios::app);
									fout << reg_no << " " << percentage << "%" << endl;

								}
							}

						}

					}
					else
					{
						cout << "pswd file not opened!";
					}

				}
				if (found_pass == false)
				{
					cout << "Password not matched!";
				}


			}
			if (found_reg == false)
			{
				cout << "There is no such registration in record!";
			}
		}
		else
		{
			cout << "Reg file not opened!";
		}


	}
	return 0;
}

