#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	ofstream fout,fout1;
	ifstream fin;
	fout.open("febiocone.txt");
	int n = 0, n1 = 0, n2 = 1, next = 0,counter=0;

	cout << "enter number" << endl;
	cin >> n;
	fout << "febicone series is : " << n1 << " , " << n2 <<" , ";
	next = n1 + n2;
	while (counter != n-2)
	{
		fout << next << " , ";
		counter++;
		n1 = n2;
		n2 = next;
		next = n1 + n2;
	}
	cout << endl;
	fout.close();
	fin.open("febiocone.txt");
	fout1.open("febiocone.txt", ios::app);
	int no = 0, n3 = 0, n4 = 1, next1 = 0, counter1 = 0;

	cout << "enter number" << endl;
	cin >> no;
	fout <<endl<< "febicone series is : " << n3 << " , " << n4 << " , ";
	next = n3 + n4;
	fout << endl;
	while (counter1 != no-2 )
	{
		fout1 << next1 << " , ";
		counter1++;
		n3 = n4;
		n4 = next1;
		next1 = n3 + n4;
	}
	fin.close();
	fout1.close();


	system("pause");
	return 0;
}