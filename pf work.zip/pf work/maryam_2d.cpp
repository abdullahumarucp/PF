#include<iostream>
using namespace std;
void Initialize(int** ptr, int rows, int col)
{
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j <col; j++)
		{
			ptr[i][j] = 0;
		}

	}
}
void display(int** ptr, int rows, int col)
{
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < col; j++)
		{
			cout << ptr[i][j] << " ";
		}
		cout << endl;
	}
}
int main()
{
	int row = 0, col = 0;
	cout << "Write no of rows: " << endl;
	cin >> row;
	cout << "Write no of col: " << endl;
	cin >> col;
	int*arr;
	arr = new int[row*col];
	int** arrd = new int*[row];
	for (int i = 0; i < row; i++) {
		arrd[i] = new int[col];
	}
	Initialize(arrd, row, col);
	cout << "Enter array numbers" << endl;
	for (int i = 0; i < col; i++){
		for (int j = 0; j < row; j++)
		{
			cin >> arrd[i][j];
		}
	}

	display(arrd, col, row);
	cout << endl;

	for (int i = 0; i < col; i++)
	{
		for (int j = 0; j < row; j++)
		{
			cout << arrd[i][j] << " ";
		}
	}
	cout << endl;
	cout << "one day array is: " << endl;
	for (int k = 0; k < 1; k++)
	{
		for (int i = 0; i < col; i++)
		{
			for (int j = 0; j < row; j++)
			{
				arr[k] = arrd[i][j];
				cout << arr[k] << " ";
			}
		}
	}

	system("pause");
	return 0;
}