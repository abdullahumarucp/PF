#include<iostream>
#include<fstream>
using namespace std;
const int c = 3;
const int c2 = 3;

void file_open(ifstream& fin);
void file_close(ifstream& fin);
void file_reading(ifstream&fin, int arr[][c], int r);
void max_value(int arr[][c], int r);
void min_value(int arr[][c], int r);
void new_id(int arr2[][c2], int r2);
void id_diagonal(int arr2[][c2], int r2);
void id_file(ofstream &fout, int arr2[][c2], int r2);
void file2_open(ofstream& fout);
void file2_close(ofstream &fout);
void input_arr2(int arr2[][c2],int r2);

int main()
{
	ifstream fin;
	ofstream fout;



	const int r = 4;
	const int r2 = 3;
	
	file_open(fin);
	int arr[r][c] = { 0 };
	file_reading(fin, arr, r);
	max_value(arr, r);
	min_value(arr, r);
	int arr2[r2][c2] = { 0 };
	input_arr2(arr2, r2);
	new_id(arr2, r2);
	file2_open(fout);
	id_file(fout, arr2, r2);
	file_close(fin);
	file2_close(fout);
	system("pause");
	return 0;
}





void file_open(ifstream& fin)
{
	fin.open("data.txt");
	if (fin.is_open())
	{
		cout << "file found " << endl;
	}
	else
	{
		cout << "file not found " << endl;
	}
}
void file2_open(ofstream& fout)
{
	fout.open("data1");
}

void file_close(ifstream& fin)
{
	cout << "File Closed" << endl << endl;
	fin.close();
}


void file_reading(ifstream&fin, int arr[][c], int r)
{
	for (int i = 0; i < r; i++)
	{
		for (int j = 0; j < c; j++)
		{
			fin >> arr[i][j];
		}
		cout << endl;
	}
	for (int i = 0; i < r; i++)
	{
		for (int j = 0; j < c; j++)
		{
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;
}

void  max_value(int arr[][c], int r)
{
	int max = 0;
	for (int i = 3; i <4; i++)
	{
		for (int j = 0; j <c; j++)
		{
			if (arr[i][j]<arr[i][j + 1])
			{
				max = arr[i][j + 1];
			}
		}
	}
	cout << " 3 row's highest value = " << max << endl;
	cout << endl;
}

void min_value(int arr[][c], int r)
{
	int min = 0;
	for (int i = 2; i < c ; i++)
	{
		for (int j = r; j > 0; j--)
		{
			if (arr[i][j] >arr[j - 1][i])
			{
				min = arr[j - 1][i];
			}
		}
	}
	cout << " 2 column lowest value = " << min << endl;
	cout << endl;
}

void input_arr2(int arr2[][c2], int r2)
{
	cout << endl;
	cout << "new metrix of 3*3" << endl;
	for (int i = 0; i < r2;i++)
	{
		for (int j = 0; j < c2; j++)
		{
			cout << "enter in matrix " << i << "," << j << " : ";
			cin >> arr2[i][j];
		}
		cout << endl;
	}	
		for (int i = 0; i < r2; i++)
		{
			for (int j = 0; j < c2; j++)
			{
				cout<< arr2[i][j]<< " ";
			}
			cout << endl;
		}
		cout << endl;
}

void new_id(int arr2[][c2], int r2)
{
	for (int i = 0; i < r2; i++)
	{
		for (int j = 0; j < c2; j++)
		{
			if (j - i == 0)

			{
				arr2[i][j] = 1;
			}
			else
			{
				arr2[i][j] = 0;
			}
		}
	}
	for (int i = 0; i < r2; i++)
	{
		for (int j = 0; j < c2; j++)
		{
			cout << arr2[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;
}

void id_file(ofstream &fout, int arr2[][c2], int r2)
{
	cout << "check file in folder " << endl;
	for (int i = 0; i < r2; i++)
	{
		for (int j = 0; j < c2; j++)
		{
			fout << arr2[i][j] << " ";
		}
		fout << endl;
	}
}


void file2_close(ofstream &fout)
{
	fout.close();
}