#include<iostream>
#include<fstream>
using namespace std;
void f_open(ifstream &f, char arr[]);
void f_read(ifstream &f, int arr1[], int s);
int main()
{
	ifstream fin;
	char arr[20] = { '\0' };
	int arr1[5] = { 0 };
	cout << "enter file name with .txt" << endl;
	cin.getline(arr, 20);
	f_open(fin, arr);
	f_read(fin, arr1, 5);
	for (int i = 0; i < 5; i++)
	{
		cout << arr1[i] << endl;
	}

	system("pause");
	return 0;
}

void f_open(ifstream &f, char arr[])
{
	f.open(arr);
	if (!f.is_open())
	{
		cout << "file not found" << endl;
	}
}

void f_read(ifstream &f, int arr1[], int s)
{
	for (int i = 0; i < s; i++)
	{
		f >> arr1[i];
	}
}


