#include<iostream>
#include<string.h>
using namespace std;
int main()
{
	char str[200] = { '\0' };
	char word[20] = { '\0' };
	int i = 0;
	int j = 0;
	int strLen = 0;
	int wrdLen = 0;
	int tmp = 0;
	int chk = 0;
	cout << "Enter the sentence: ";
	cin.getline(str, 200);
	cout << "Enter the word to remove: ";
	cin >> word;
	strLen = strlen(str);
	wrdLen = strlen(word);
	for (i = 0; i<strLen; i++)
	{
		tmp = i;
		for (j = 0; j<wrdLen; j++)
		{
			if (str[i] == word[j])
				i++;
		}
		chk = i - tmp;
		if (chk == wrdLen)
		{
			i = tmp;
			for (j = i; j<(strLen - wrdLen); j++)
				str[j] = str[j + wrdLen];
			strLen = strLen - wrdLen;
			str[j] = '\0';
		}
	}
	cout << endl;
	cout << "New sentence: " << str;
	cout << endl;
	system("pause");
	return 0;
}