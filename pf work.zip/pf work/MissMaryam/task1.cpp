#include<iostream>
#include<string>
using namespace std;
#define MAX_SIZE 10
// Function to print the first
// and last character of each word.

void FirstAndLast(string str)
{
	int i;

	for (i = 0; i < str.length(); i++)
	{
		// If it is the first word
		// of the string then print it.
		if (i == 0)
			cout << str[i];

		// If it is the last word of the string
		// then also print it.
		if (i == str.length() - 1)
			cout << str[i];

		// If there is a space
		// print the successor and predecessor
		// to space.
		if (str[i] == ' ')
		{
			cout << str[i - 1] << " " << str[i + 1];
		}
	}
}

// Driver code
int main()
{
	char string[MAX_SIZE];
	cout << "Enter any string  : ";
	cin >> string;
	FirstAndLast(string);
	system("pause");
	return 0;

}