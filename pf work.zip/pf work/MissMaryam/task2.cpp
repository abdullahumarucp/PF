
#include<iostream>
#include<string> 
using namespace std;

int main() 
{
	string out= "<<>>";
	cout<<"enter string "<<endl; 
	string str2;
	cin>>str2;
	for(int i= 0;i<2;i++)
	{ cout<<out[i]; } 
	cout<<str2; 
	for(int i=2; i<4;i++)
	{ cout<<out[i]; }
	system("pause");
	return 0; 
}