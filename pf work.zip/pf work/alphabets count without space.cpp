#include<fstream>
#include<iostream>
using namespace std;
int main()
{
	ifstream fin;
	ofstream fout;
	int i = 0;
	int word = 0;
	char data[20] = {};
	fin.open("a.txt");
	if (!fin.is_open())
	{
		cout << "file not found" << endl;
	}
	else
	{
		while (!fin.eof())
		{
			fin.getline(data, 20);
			while (data[i] != '\0')
			{
				if (data[i] != ' ')
				{
					word++;
				}
				i++;
			}
		}
		cout << "Total no of alphabets excluding spaces = " << word << endl;
	}
	fin.close();
	fout.close();




	system("pause");
	return 0;
}