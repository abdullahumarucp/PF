#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	ifstream fin;
	ofstream fout;
	int num = 0;
	char name[20] = { '\0' };
	fin.open("data.txt");
	

	if (!fin.is_open())
	{
		cout << " not found" << endl;
	}
	else
	{
		while (!fin.eof())
		{
			fin >> num;
			fin.ignore();
			fin.getline(name, 20);
			
	}
		fin.close();
		fout.close();


	system("pause");
	return 0;
}