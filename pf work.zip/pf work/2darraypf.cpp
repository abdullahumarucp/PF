#include<iostream>
using namespace std;
int main()
{

	int i, j;
	const int c = 4, m = 5;
	int arr[c][m] = { 0 };
	int arr2[4][5] = { 0 };
	for (i = 0; i < c; i++)
	{
		for (j = 0; j < m; j++)
		{
			cout << "matric " << i << j << "enter values :";
			cin >> arr[i][j];
		}
	}
	cout << endl;

	cout << "values column vise" << endl;
	for (i = 0; i < c; i++)
	{
		for (j = 0; j < m; j++)
		{
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;

	cout << "new array" << endl;
	for (i = 0; i < c; i++)
	{
		for (int j = 0; j< m; j++)
		{
			arr2[i][j] = arr[i][j];
			cout << arr2[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;
	cout << "diagonally" << endl;
	for (i = 0; i < c; i++)
	{
		for (j = 0; j < m; j++)
		{
			if (j == i)
				cout << arr[i][j] << "\t";
			else
				cout << " " << "\t";
		}
		cout << "\n";
	}

	cout << endl;

	arr[4][1] = 0;//there is no 4 index on row so it do not exist.
	arr[2][2] = 1;
	arr[3][4] = arr[3][4] + 500;
	cout << "                 after change " << endl;
	for (i = 0; i < 4; i++)
	{
		for (j = 0; j < 5; j++)
		{
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}

	cout << endl;


	system("pause");
	return 0;
}