#include<iostream>//header file
#include<fstream>//header file
using namespace std;

int grade_calculator(int x);//heading(function)

int main()//main function
{
	ifstream inData;
	ofstream outData;
	int number = 0;
	int marks[10] = { 0 };
	char grade[10] = { '\0' };
	inData.open("marks.txt");//opening a file
	if (!inData.is_open())//check
	{
		cout << "file not found!" << endl;
	}
	else
	{
		outData.open("result.txt");//creating a file
		for (int i = 0; i < 10; i++)
		{
			inData >> number;
			marks[i] = number;
			grade[i] = grade_calculator(marks[i]);//calling function
			outData << number << " " << grade[i] << endl;//print
		}
	}
	inData.close();//closing
	outData.close();//closing


	system("pause");
	return 0;//return
}
int grade_calculator(int x)//heading(function)
{
	if (x >= 90)
	{
		return 'A';//return
	}
	else if (x >= 80)
	{
		return 'B';//return
	}
	else if (x >= 70)
	{
		return 'C';//return
	}
	else if (x >= 60)
	{
		return 'D';//return
	}
	else
	{
		return 'F';//return
	}
}