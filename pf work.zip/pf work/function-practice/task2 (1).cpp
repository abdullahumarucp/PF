#include<iostream>
using namespace std;


int input()
{
	int n = 0;
	cout << "Enter the number : ";
	cin >> n;
	return n;

}

void sum(int a,int b,int c,int d,int e, int f,int g, int h,int i, int j)
{
	int sum = 0;
	sum = a + b + c + d + e + f + g + h + i + j;
	cout << "the sum of all the values present in array is : " << sum << endl;
}

int main()
{
	int arr[10] = {}; 
	arr[0] = input();
	arr[1] = input();
	arr[2] = input();
	arr[3] = input();
	arr[4] = input();
	arr[5] = input();
	arr[6] = input();
	arr[7] = input();
	arr[8] = input();
	arr[9] = input();
	sum(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], arr[6], arr[7], arr[8], arr[9]);

	return 0;
}