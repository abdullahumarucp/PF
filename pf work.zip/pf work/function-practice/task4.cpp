#include<iostream>
using namespace std;

int input()
{
	int n = 0;
	cout << "Enter the number : ";
	cin >> n;
	return n;
}
void check(int a,int b,int c,int d,int e,int f)
{
	cout << endl<<endl<< "                After checking : " << endl;
	if (a%2==0)
	{
		cout << "0  ";
	}
	else
	{
		cout << "1  ";
	}
	if (b%2==0)
	{
		cout << "0  ";
	}
	else
	{
		cout << "1  ";
	}
	if (c%2==0)
	{
		cout << "0  ";
	}
	else
	{
		cout << "1  ";
	}
	if (d%2==0)
	{
		cout << "0  ";
	}
	else
	{
		cout << "1  ";
	}
	if (e % 2 == 0)
	{
		cout << "0  ";
	}
	else
	{
		cout << "1  ";
	}
	if (f % 2 == 0)
	{
		cout << "0  ";
	}
	else
	{
		cout << "1  ";
	}
	cout << endl;
}



int main()
{
	int arr[6] = { '\0' };
	arr[0] = input();
	arr[1] = input();
	arr[2] = input();
	arr[3] = input();
	arr[4] = input();
	arr[5] = input();
	check(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5]);

	return 0;
}