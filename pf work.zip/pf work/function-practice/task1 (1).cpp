#include<iostream>
using namespace std;



float length()
{
	float length = 0;
	cout << "Enter valuue for length : ";
	cin >> length;
	return length;
}

float width()
{
	float width = 0;
	cout << "Enter valuue for width : ";
	cin >> width;
	return width;
}

void peri()
{
	float peri = 0;
	float l = length();
	float w = width();
	peri = 2 * (l + w);
	
	cout << "The Perimeter for Length : '" << l << "' and Width : '" << w << "' is = " << peri << endl;
	
}

int main()
{
	
	peri();
	
	
	return 0;
}